-- DROP TABLE IF EXISTS threads;

-- CREATE TABLE threads (
--         wa_id TEXT PRIMARY KEY,
--         query TEXT NOT NULL,
--         status INTEGER DEFAULT NULL
-- ); 
